
import type { Track, Show, NewsPost } from './types';

export const TRACKS: Track[] = [
  {
    id: 1,
    title: 'YA NO SOMOS NADA?',
    coverArtUrl: 'https://i.ytimg.com/vi/VkFNFsPEHos/maxresdefault.jpg',
    description: 'A song about the confusing and painful end of a relationship, questioning what remains when love fades.',
    releaseType: 'Single',
    year: 2024,
    youtubeUrl: 'https://www.youtube.com/embed/VkFNFsPEHos',
    streamingLinks: {
      spotify: '#',
      appleMusic: '#',
    },
  },
  {
    id: 2,
    title: 'Luces de Neón',
    coverArtUrl: 'https://picsum.photos/seed/neon/900/900',
    description: 'An upbeat track capturing the vibrant, chaotic energy of a night out in the city and a fleeting connection.',
    releaseType: 'Single',
    year: 2023,
    youtubeUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    streamingLinks: {
      spotify: '#',
      appleMusic: '#',
    },
  },
  {
    id: 3,
    title: 'Ecos Rotos (EP)',
    coverArtUrl: 'https://picsum.photos/seed/echo/900/900',
    description: 'A 4-track EP exploring themes of heartbreak, reflection, and the eventual path to self-rediscovery.',
    releaseType: 'EP',
    year: 2023,
    youtubeUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    streamingLinks: {
      spotify: '#',
      appleMusic: '#',
    },
  },
  {
    id: 4,
    title: 'Serendipia',
    coverArtUrl: 'https://picsum.photos/seed/serendipity/900/900',
    description: 'Acoustic ballad about finding unexpected happiness in the small, unplanned moments of life.',
    releaseType: 'Single',
    year: 2022,
    youtubeUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    streamingLinks: {
      spotify: '#',
      appleMusic: '#',
    },
  },
   {
    id: 5,
    title: 'Gravedad Cero',
    coverArtUrl: 'https://picsum.photos/seed/gravity/900/900',
    description: 'A track with electronic influences, describing the feeling of weightlessness and escape that music provides.',
    releaseType: 'Single',
    year: 2024,
    youtubeUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    streamingLinks: {
      spotify: '#',
      appleMusic: '#',
    },
  },
];

export const SHOWS: Show[] = [
    { id: 1, date: '2024-09-15', city: 'Los Angeles, CA', venue: 'The Troubadour', ticketLink: '#', status: 'On Sale' },
    { id: 2, date: '2024-09-18', city: 'San Francisco, CA', venue: 'The Fillmore', ticketLink: '#', status: 'On Sale' },
    { id: 3, date: '2024-10-02', city: 'New York, NY', venue: 'Bowery Ballroom', ticketLink: null, status: 'Sold Out' },
    { id: 4, date: '2024-07-20', city: 'Chicago, IL', venue: 'Lincoln Hall', ticketLink: null, status: 'Past' },
    { id: 5, date: '2024-06-12', city: 'Austin, TX', venue: 'The Parish', ticketLink: null, status: 'Past' },
];

export const NEWS_POSTS: NewsPost[] = [
    { id: 1, title: 'New Single "Gravedad Cero" Out Now!', date: '2024-08-01', excerpt: 'My latest track is finally here. I poured a lot of late nights and synth experiments into this one. It\'s about that feeling of escape...', imageUrl: 'https://picsum.photos/seed/gravity/800/600' },
    { id: 2, title: 'Fall Tour Dates Announced', date: '2024-07-25', excerpt: 'So excited to hit the road this September and play some new songs for you all. We\'re hitting LA, SF, and a sold-out show in NYC!', imageUrl: 'https://picsum.photos/seed/tourbus/800/600' },
    { id: 3, title: 'Studio Diary: Ecos Rotos', date: '2023-11-10', excerpt: 'A look back at the process of creating the "Ecos Rotos" EP. It was a journey of discovery, healing, and finding a new sound.', imageUrl: 'https://picsum.photos/seed/studio/800/600' },
];
import React from 'react';

const About: React.FC = () => {
  return (
    <section id="about" className="py-20 sm:py-28 bg-slate-900">
      <div className="container mx-auto px-6">
        <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-16">
          <div className="w-full lg:w-2/5">
            <div className="relative animate-subtle-pulse">
              <div className="absolute -inset-2 bg-gradient-to-br from-emerald-500 to-cyan-500 rounded-lg blur opacity-60"></div>
              <img
                src="https://picsum.photos/seed/singer/600/700"
                alt="Musician Fresh Richie"
                className="relative w-full h-auto rounded-lg shadow-2xl"
              />
            </div>
          </div>
          <div className="w-full lg:w-3/5">
            <h2 className="text-4xl md:text-5xl font-serif font-bold text-white mb-6">The Artist</h2>
            <div className="space-y-4 text-lg text-slate-300 leading-relaxed">
              <p>
                My name is Fresh Richie, an independent singer-songwriter navigating the world one song at a time. For me, music is the most honest form of storytelling. I write my own lyrics, produce my own tracks, and handle every aspect of sharing my music with you. 
              </p>
              <p>
                This journey is about full creative control—transforming raw emotion and late-night ideas into a finished sound that is authentically mine. From the first chord struck on a guitar to the final mix, every note is a piece of my story.
              </p>
              <p>
                Being an independent artist means building a direct connection with my listeners. Your support fuels this passion and allows me to continue creating. Thank you for being a part of this adventure.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
